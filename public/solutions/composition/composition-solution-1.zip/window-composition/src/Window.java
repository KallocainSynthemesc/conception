import java.lang.Math;

public class Window {

	final Rectangle rectangle;
	
	public Window(final int width, final int height) {
		this.rectangle = new Rectangle(width, height);
	}

	public Window(Rectangle rectangle) {
		this.rectangle = rectangle;
	}

	
	public void draw() {
		printHorizontal('#');
		for (int j = 0; j < this.rectangle.getHeight() - 2; j++) {
			if (j == (Math.floor(this.rectangle.getHeight() / 2) - 1)) {
				printHorizontal('#');
			} else {
				printVertical('#');
			}
		}
		printHorizontal('#');
	}

	private void printVertical(char marker) {
		System.out.print(marker);
		for (int j = 0; j < this.rectangle.getWidth() - 2; j++) {
			if (j == (Math.floor(this.rectangle.getWidth() / 2) - 1)) {
				System.out.print('#');
			} else {
				System.out.print(' ');
			}
		}
		System.out.println(marker);
	}

	private void printHorizontal(char marker) {
		for (int j = 0; j < this.rectangle.getWidth() - 1; j++) {
			System.out.print(marker);
		}
		System.out.println(marker);
	}
	
	public int calculateArea() {
		return this.rectangle.calculateArea();
	}
}