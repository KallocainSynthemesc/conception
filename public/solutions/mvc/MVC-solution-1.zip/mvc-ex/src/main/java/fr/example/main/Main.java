package fr.example.main;

import fr.example.controller.PersonController;
import fr.example.dao.PersonInMemoryStore;
import fr.example.services.PersonServiceImpl;
import fr.example.view.ConsoleInterface;	

public class Main {

	public static void main(String[] args) {
		final ConsoleInterface ui = new ConsoleInterface();
		final PersonInMemoryStore personDao = new PersonInMemoryStore();
		final PersonServiceImpl personService = new PersonServiceImpl(personDao);
		final PersonController inventoryController = new PersonController(ui, personService);

		inventoryController.startup();

		while (true) {
			inventoryController.showChoices();
			inventoryController.getChoice();
			inventoryController.choiceAction();
		}
	}
}
