package fr.example.services;

import java.util.List;

import fr.example.model.Person;

public interface PersonService {
	
	public Person find(String id);

	public List<Person> findAll();

	public void save(Person person);

	public void remove(Person person);

	public boolean exists(Person person);

	public long size();
	
}
