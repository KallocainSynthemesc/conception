package fr.example.view;

public interface UserInterface<T> {
	  public void displayMessage(T message);
	  public T getUserInput();
}

