package fr.example.services;

import java.util.List;

import fr.example.dao.PersonDAO;
import fr.example.model.Person;

public class PersonServiceImpl implements PersonService {

	final PersonDAO dao;

	public PersonServiceImpl(PersonDAO dao) {
		this.dao = dao;
	}

	public Person find(String id) {
		return dao.find(id);
	}

	public List<Person> findAll() {
		return dao.findAll();
	}

	public void save(Person person) {
		long id = this.dao.size() + 1;
		person.setPersonNum(id);
		dao.save(person);
	}

	public void remove(Person person) {
		dao.remove(person);
	}

	public boolean exists(Person person) {
		return dao.exists(person);
	}

	public long size() {
		return Long.valueOf(dao.size());
	}
}