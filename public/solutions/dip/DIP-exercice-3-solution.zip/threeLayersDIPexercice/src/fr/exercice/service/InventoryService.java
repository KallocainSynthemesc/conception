package fr.exercice.service;

import java.util.List;

public interface InventoryService<T> {
    
    public void addToInventory(T t);
    
    public List<T> listInventory();
}
