package fr.exercice.view;

public interface UserInterface<T> {
	  public void displayMessage(T message);
	  public T getUserInput();
}
