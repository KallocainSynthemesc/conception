package fr.exercice.dao;

import java.util.ArrayList;
import java.util.List;

import fr.exercice.model.Product;

//Data Access Layer
public class ProductDAO implements DAOable<Product>{
    private final List<Product> products;
    
    public ProductDAO() {
        this.products = new ArrayList<Product>();
    }

	@Override
	public void add(Product t) {
		products.add(t);
	}

	@Override
	public List<Product> list() {
		return products;
	}

	@Override
	public boolean remove(Product t) {
		return products.remove(t);
	}
}
