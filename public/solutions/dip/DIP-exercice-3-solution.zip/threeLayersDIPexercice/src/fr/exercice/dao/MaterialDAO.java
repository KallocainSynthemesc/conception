package fr.exercice.dao;

import java.util.ArrayList;
import java.util.List;

import fr.exercice.model.Material;
import fr.exercice.model.Product;

//Data Access Layer
public class MaterialDAO implements DAOable<Material>{
    private final List<Material> materials;
    
    public MaterialDAO() {
        this.materials = new ArrayList<Material>();
    }

	@Override
	public void add(Material t) {
		materials.add(t);
	}

	@Override
	public List<Material> list() {
		return materials;
	}

	@Override
	public boolean remove(Material t) {
		return materials.remove(t);
	}
}
