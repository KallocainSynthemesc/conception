package fr.exercice.dao;

import java.util.List;

public interface DAOable<T> {
	public void add(T t);
	public List<T> list();
	public boolean remove(T t);
}
