package fr.kili.exercice.sender;

public class TextMessageSender {
	public void sendTextMessage(String message) {
		System.out.println("Text sent: " + message);
    }
}
