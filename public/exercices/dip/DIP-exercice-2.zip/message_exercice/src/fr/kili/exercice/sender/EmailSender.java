package fr.kili.exercice.sender;

public class EmailSender {
    public void sendEmail(String message) {
        System.out.println("Email sent: " + message);
    }
}
