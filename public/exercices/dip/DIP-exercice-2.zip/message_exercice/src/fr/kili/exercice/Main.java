package fr.kili.exercice;

import fr.kili.exercice.service.MessageService;

public class Main {
	public static void main(String[] args) {
		MessageService service = new MessageService();
		service.sendEmail("Bonjour de la part de l'exp�diteur de l'email");
		service.sendTextMessage("Bonjour de la part de l'exp�diteur du message");
	}
}
