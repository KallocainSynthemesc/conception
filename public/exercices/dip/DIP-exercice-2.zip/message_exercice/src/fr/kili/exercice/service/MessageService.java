package fr.kili.exercice.service;

import fr.kili.exercice.sender.EmailSender;
import fr.kili.exercice.sender.TextMessageSender;

public class MessageService {
    private EmailSender emailSender;
    private TextMessageSender textMessageSender;
    
    public MessageService() {
        emailSender = new EmailSender();
        textMessageSender = new TextMessageSender();
    }
    
    public void sendEmail(String message) {
        emailSender.sendEmail(message);
    }
    
    public void sendTextMessage(String message) {
        textMessageSender.sendTextMessage(message);
    }
}
