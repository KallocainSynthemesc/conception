package fr.kili.exercice.devices;

import fr.kili.exercice.interfaces.SwitchableDevice;

public class Lamp implements SwitchableDevice {

	public void turnOn() {
		System.out.println("La lumi�re est allum�e");
	}

	public void turnOff() {
		System.out.println("La lumi�re est �teinte");
	}
}
