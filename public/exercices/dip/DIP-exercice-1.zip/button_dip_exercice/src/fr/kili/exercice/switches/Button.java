package fr.kili.exercice.switches;

import fr.kili.exercice.interfaces.SwitchableDevice;

public class Button {
	private SwitchableDevice device;
	private boolean isSwitched = false;

	public Button(final SwitchableDevice device) {
		this.device = device;
	}

	public void switchState() {
		if (isSwitched) {
			device.turnOff();
		} else {
			device.turnOn();
		}
		isSwitched = isSwitched ? false : true;
	}
}
