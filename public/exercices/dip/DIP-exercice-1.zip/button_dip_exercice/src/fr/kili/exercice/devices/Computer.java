package fr.kili.exercice.devices;
import fr.kili.exercice.interfaces.SwitchableDevice;

public class Computer implements SwitchableDevice {

	public void turnOn() {
		System.out.println("L'ordinateur est allum�");
	}

	public void turnOff() {
		System.out.println("L'ordinateur est �teint");
	}
}
