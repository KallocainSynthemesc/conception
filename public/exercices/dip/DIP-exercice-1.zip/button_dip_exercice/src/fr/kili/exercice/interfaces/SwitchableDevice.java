package fr.kili.exercice.interfaces;

public interface SwitchableDevice {
	void turnOn();
	void turnOff();
}
