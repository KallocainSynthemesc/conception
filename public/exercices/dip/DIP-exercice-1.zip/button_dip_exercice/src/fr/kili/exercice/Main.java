package fr.kili.exercice;

import fr.kili.exercice.devices.Computer;
import fr.kili.exercice.devices.Lamp;
import fr.kili.exercice.switches.Button;

public class Main {
	public static void main(String[] args) {
		final Lamp lamp = new Lamp();
		final Button lampButton = new Button(lamp);
		lampButton.switchState();
		lampButton.switchState();

		final Computer computer = new Computer();
		final Button computerButton = new Button(computer);
		computerButton.switchState();
		computerButton.switchState();
	}
}
