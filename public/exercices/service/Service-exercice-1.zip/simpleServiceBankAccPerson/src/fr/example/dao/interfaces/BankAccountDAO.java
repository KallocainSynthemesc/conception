package fr.example.dao.interfaces;

import java.util.List;

import fr.example.model.BankAccount;

public interface BankAccountDAO {
    
    /**
     * Find the entity T for the specified identifier id
     *
     * @param id the identifier for the entity
     * @return the entity
     */
    public BankAccount find(String id);
	 
    /**
     * Find all entities of T<br>
     * <b>Warning : Be careful of the use of findAll and memory consumption</b>
     *
     * @return the list of entities
     */
    public List<BankAccount> findAll();

    /**
     * Save the specified entity T and return the Id
     *
     * @param t the entity to save
     * @return the Id
     */
    public void save(BankAccount t);

    /**
     * Delete the specified entity T
     *
     * @param t the entity to remove
     */
    public void remove(BankAccount t);
    
    
    /**
     *Verify if the specified entity T exists
     *
     * @param t the entity to remove
     */
    public boolean exists(BankAccount t);
	
}

