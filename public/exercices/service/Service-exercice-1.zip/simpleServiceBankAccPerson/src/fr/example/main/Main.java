package fr.example.main;

import java.util.List;

import fr.example.dao.impl.BankAccountInMemoryStore;
import fr.example.dao.impl.PersonInMemoryStore;
import fr.example.model.BankAccount;
import fr.example.model.Person;
import fr.example.services.BankAccountService;
import fr.example.services.PersonService;	

public class Main {
    
	public static void main(String[] args) {
		Person person1 = new Person(1L, "Kilian", "Schropp");
		Person person2 = new Person(2L, "Holz", "Michel");
		Person person3 = new Person(3L, "Peter", "M�ller");
		
		BankAccount account = new BankAccount("abz", person1, person2, "BGE-bank");
		BankAccount account2 = new BankAccount("yz-hez", person2, person3, "big-K-bank");
		
		PersonInMemoryStore personDao = new PersonInMemoryStore();
		
		PersonService personService = new PersonService(personDao);
		personService.save(person1);
		personService.save(person2);
		personService.save(person3);
		
		BankAccountInMemoryStore bankaccountDao = new BankAccountInMemoryStore();
		BankAccountService bankaccountService = new BankAccountService(bankaccountDao);
		bankaccountService.save(account);
		bankaccountService.save(account2);
		
		List<Person> jdoPersons = personService.findAll();
		printPersons(jdoPersons);
		
		List<BankAccount> jdoAccounts = bankaccountService.findAll();
		printBankAccount(jdoAccounts);
    }
	
	private static void printPersons(List<Person> persons) {
		for(Person person : persons) {
			System.out.println("Person: prenom -> " + person.getFirstName() + " ,nom -> " + person.getLastName());
		}
	}
	
	private static void printBankAccount(List<BankAccount> bankAccount) {
		for(BankAccount account : bankAccount) {
			System.out.println("BankAccount: nom bank -> " + account.getBankName() + " ,account num -> " + account.getAccountIdentifier());
		}
	}
}
