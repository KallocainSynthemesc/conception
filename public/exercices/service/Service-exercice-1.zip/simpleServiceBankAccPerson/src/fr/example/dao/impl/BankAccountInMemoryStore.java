package fr.example.dao.impl;

import java.util.ArrayList;
import java.util.List;

import fr.example.dao.interfaces.BankAccountDAO;
import fr.example.model.BankAccount;

public class BankAccountInMemoryStore implements BankAccountDAO{
	
	private final List<BankAccount> store = new ArrayList<BankAccount>();
	
	public BankAccount find(String id) {
		BankAccount person = store.stream()
                .filter(pers -> id.equals(pers.getAccountIdentifier()))
                .findAny()
                .orElse(null);
        return person;
	}

	public List<BankAccount> findAll() {
		return store;
    }

	public void save(BankAccount bankAccount) {
		if(!exists(bankAccount)) {
			store.add(bankAccount);
		}
	}

	public void remove(BankAccount bankAccount) {
		store.remove(bankAccount);
	}
	
	public boolean exists(BankAccount bankAccount) {
		return store.contains(bankAccount);
	}
}
