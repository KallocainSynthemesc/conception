package fr.example.main;

import java.util.List;

import fr.example.model.Person;
import fr.example.services.PersonService;	

public class Main {
    
	public static void main(String[] args) {
		Person person1 = new Person(1L, "Kilian", "Schropp");
		Person person2 = new Person(2L, "Holz", "Michel");
		Person person3 = new Person(3L, "Peter", "M�ller");
		
		PersonService personService = new PersonService();
		personService.save(person1);
		personService.save(person2);
		personService.save(person3);
		
		List<Person> jdoPersons = personService.findAll();
		printPersons(jdoPersons);
    }
	
	private static void printPersons(List<Person> persons) {
		for(Person person : persons) {
			System.out.println("Person: prenom -> " + person.getFirstName() + " ,nom -> " + person.getLastName());
		}
	}
}
