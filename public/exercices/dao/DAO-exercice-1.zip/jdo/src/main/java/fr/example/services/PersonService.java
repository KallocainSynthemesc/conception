package fr.example.services;

import java.util.List;

import fr.example.dao.PersonInMemoryStore;
import fr.example.dao.PersonJDO;
import fr.example.model.Person;

public class PersonService {
	
	final PersonJDO personJDO = new PersonJDO();
	final PersonInMemoryStore personInMem = new PersonInMemoryStore();
	
	public Person find(String id) {
		return personJDO.find(id);
	}

	public List<Person> findAll() {
		return personJDO.findAll();
    }

	public void save(Person person) {
		personJDO.save(person);
	}

	public void remove(Person person) {
		personJDO.remove(person);
	}
	
	public boolean exists(Person person) {
		return personJDO.exists(person);
	}
}
