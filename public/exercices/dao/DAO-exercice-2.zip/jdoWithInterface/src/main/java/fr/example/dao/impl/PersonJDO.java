package fr.example.dao.impl;

import java.util.List;

import javax.jdo.Query;
import javax.jdo.Transaction;

import fr.example.dao.interfaces.PersonDAO;
import fr.example.model.Person;
import fr.example.persistance.PersistanceManagerSingleton;

public class PersonJDO implements PersonDAO{

	final PersistanceManagerSingleton pms = PersistanceManagerSingleton.getInstance();

	public Person find(String id) {
		return pms.getPersistenceManager().getObjectById(Person.class, id);
	}

	public List<Person> findAll() {
        Query<Person> query = pms.getPersistenceManager().newQuery(Person.class);
        return query.executeList();
    }

	public void save(Person person) {
		Transaction tx = pms.getPersistenceManager().currentTransaction();
		
		if(!exists(person)) {
			try {
				tx.begin();
				pms.getPersistenceManager().makePersistent(person);
				tx.commit();
			} finally {
				if (tx.isActive()) {
					tx.rollback();
				}
			}
		}
	}

	public void remove(Person person) {
		pms.getPersistenceManager().deletePersistent(person);
	}
	
	public boolean exists(Person person) {
		Query<Person> query = pms.getPersistenceManager().newQuery(Person.class, "firstName == :idParam");
        query.setUnique(true);
        query.setParameters(person.getFirstName());
        Person existingPerson = query.executeUnique();
        return existingPerson == null ? false : true;
	}

}
