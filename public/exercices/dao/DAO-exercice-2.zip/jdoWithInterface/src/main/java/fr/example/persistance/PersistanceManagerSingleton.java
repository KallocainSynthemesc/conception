package fr.example.persistance;

import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;

import org.datanucleus.api.jdo.JDOPersistenceManagerFactory;
import org.datanucleus.metadata.PersistenceUnitMetaData;

public class PersistanceManagerSingleton {
    private PersistenceManagerFactory pmf;
    private PersistenceManager pm;
    
    private final static PersistanceManagerSingleton INSTANCE = new PersistanceManagerSingleton();
    
    public static PersistanceManagerSingleton getInstance() {
    	return INSTANCE;
    }
    
    private PersistanceManagerSingleton() {
    	PersistenceUnitMetaData pumd = new PersistenceUnitMetaData("dynamic-unit", "RESOURCE_LOCAL", null);
        pumd.addProperty("javax.jdo.option.ConnectionURL", "xml:file:myfile_dynamicPMF.xml");
        pumd.addProperty("datanucleus.schema.autoCreateAll", "true");
        pumd.addProperty("datanucleus.xml.indentSize", "4");

        pmf = new JDOPersistenceManagerFactory(pumd, null);
        pm = pmf.getPersistenceManager();
    }
    
    public PersistenceManager getPersistenceManager() {
    	return pm;
    }
    
    public void closePersistenceManager() {
        if (pm != null && !pm.isClosed()) {
            pm.close();
        }
    }
}
