package fr.example.controller;

import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import fr.example.model.Person;
import fr.example.services.PersonService;
import fr.example.view.UserInterface;

public class PersonController {

	  final UserInterface ui;
	  final PersonService service;
	  String choice;

	  public PersonController(final UserInterface ui, final PersonService service) {
	    this.ui = ui;
	    this.service = service;
	  }

	  public void startup() {
	    ui.displayMessage("Bienvenue dans le syst�me de gestion des personnes !");
	  }

	  public void showChoices() {
	    ui.displayMessage("Veuillez choisir une action :");
	    ui.displayMessage("1. Ajouter une person");
	    ui.displayMessage("2. Voir tous les persons");
	    ui.displayMessage("3. Quitter");
	  }

	  public void getChoice() {
	    this.choice = ui.getUserInput();
	  }

	  public void choiceAction() {
	    switch (this.choice) {
	      case "1":
	        ui.displayMessage("Veuillez saisir le nom du Person :");
	        String name = ui.getUserInput();
	        ui.displayMessage("Veuillez saisir le prenom du Person :");
	        String prename = ui.getUserInput();

	        ui.displayMessage("Veuillez saisir l'age du Person :");
	        int age = Integer.parseInt(ui.getUserInput());
	        long id = this.service.size() + 1;
	        Person person = new Person(id, name, prename, age);
	        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
	        Validator validator = factory.getValidator();
	        Set<ConstraintViolation<Person>> violations = validator.validate(person);
	        
	        if(violations.isEmpty()) {
	        	this.service.save(person);
	        	ui.displayMessage("Personne ajout�e !");
	        }
	        else {
	        	for (ConstraintViolation<Person> violation : violations) {
	        		ui.displayMessage(violation.getMessage());
	        		ui.displayMessage("Personne pas ajout�e !");
	        	}	
	        }
	        
	        break;

	      case "2":
	        List<Person> persons = this.service.findAll();
	        ui.displayMessage("Tous les persons :");
	        for (Person p : persons) {
	          ui.displayMessage(p.toString());
	        }
	        break;

	      case "3":
	        ui.displayMessage("Au revoir !");
	        System.exit(0);

	      default:
	        ui.displayMessage("Choix non valide, veuillez r�essayer.");
	        break;
	    }
	  }
	}