package fr.example.model;

import java.util.Objects;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import fr.example.validation.Adult;

public class Person {

	@Min(1)
	private long personNum;
	
	@NotNull
    private String firstName;
    
    @NotNull
    private String lastName;
    
    @Adult(message = "Vous devez �tre �g� d'au moins 18 ans")
    private int age;

    public Person() {}
    
    public Person(long personNum, String firstName, String lastName, int age) {
        this.personNum = personNum;
        this.firstName = firstName;
        this.lastName = lastName;
        this.setAge(age);
    }

    public long getPersonNum() {
        return personNum;
    }

    public void setPersonNum(long personNum) {
        this.personNum = personNum;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof Person)) {
            return false;
        }
        Person otherPerson = (Person) o;
        return personNum == otherPerson.personNum
                && Objects.equals(firstName, otherPerson.firstName)
                && Objects.equals(lastName, otherPerson.lastName);
    }
    
    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + (int) (personNum ^ (personNum >>> 32));
		return result;
	}
    
    @Override
    public String toString() {
    	return "Person [personNum=" + personNum + ", firstName=" + firstName + ", lastName=" + lastName;
    }

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

}