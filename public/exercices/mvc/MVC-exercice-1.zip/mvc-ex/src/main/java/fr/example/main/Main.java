package fr.example.main;

import fr.example.controller.PersonController;
import fr.example.dao.PersonInMemoryStore;
import fr.example.services.PersonService;
import fr.example.view.UserInterface;	

public class Main {

	public static void main(String[] args) {
		final UserInterface ui = new UserInterface();
		PersonInMemoryStore personDao = new PersonInMemoryStore();
		PersonService personService = new PersonService(personDao);
		final PersonController inventoryController = new PersonController(ui, personService);

		inventoryController.startup();

		while (true) {
			inventoryController.showChoices();
			inventoryController.getChoice();
			inventoryController.choiceAction();
		}
	}
}
