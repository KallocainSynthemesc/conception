package fr.kili.exercice.interfaces;

public interface MessageSender {
    void sendMessage(String message);
}
