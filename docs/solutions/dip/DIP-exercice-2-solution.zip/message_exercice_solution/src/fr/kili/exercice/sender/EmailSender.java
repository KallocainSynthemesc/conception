package fr.kili.exercice.sender;

import fr.kili.exercice.interfaces.MessageSender;

public class EmailSender implements MessageSender{
    public void sendMessage(String message) {
        System.out.println("Email sent: " + message);
    }
}
