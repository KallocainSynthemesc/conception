package fr.kili.exercice;

import fr.kili.exercice.sender.EmailSender;
import fr.kili.exercice.sender.TextMessageSender;
import fr.kili.exercice.service.MessageService;

public class Main {
	public static void main(String[] args) {
		EmailSender emailSender = new EmailSender();
		MessageService service = new MessageService(emailSender);
		service.send("Bonjour de la part de l'exp�diteur de l'email");
		
		TextMessageSender textSender = new TextMessageSender();
		service = new MessageService(textSender);
		service.send("Bonjour de la part de l'exp�diteur du message");
	}
}
