package fr.kili.exercice.service;

import fr.kili.exercice.interfaces.MessageSender;

public class MessageService {
    private final MessageSender sender;
    
    public MessageService(MessageSender sender) {
        this.sender = sender;
    }
    
    public void send(String message) {
        sender.sendMessage(message);
    }
}
