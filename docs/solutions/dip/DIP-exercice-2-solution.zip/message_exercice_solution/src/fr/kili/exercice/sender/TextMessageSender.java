package fr.kili.exercice.sender;

import fr.kili.exercice.interfaces.MessageSender;

public class TextMessageSender implements MessageSender{
	public void sendMessage(String message) {
		System.out.println("Text sent: " + message);
    }
}
