package fr.example.dao.impl;

import java.util.ArrayList;
import java.util.List;

import fr.example.dao.interfaces.PersonDAO;
import fr.example.model.Person;

public class PersonInMemoryStore implements PersonDAO{
	
	private final List<Person> store = new ArrayList<Person>();
	
	public Person find(String id) {
		Person person = store.stream()
                .filter(pers -> id.equals(pers.getFirstName()))
                .findAny()
                .orElse(null);
        return person;
	}

	public List<Person> findAll() {
		return store;
    }

	public void save(Person person) {
		if(!exists(person)) {
			store.add(person);
		}
	}

	public void remove(Person person) {
		store.remove(person);
	}
	
	public boolean exists(Person person) {
		return store.contains(person);
	}
}
