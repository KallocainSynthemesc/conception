package fr.example.services;

import java.util.List;

import fr.example.dao.interfaces.BankAccountDAO;
import fr.example.model.BankAccount;

public class BankAccountService{
	
	final BankAccountDAO dao;
	
	public BankAccountService(BankAccountDAO dao) {
		this.dao = dao;
	}
	
	public BankAccount find(String id) {
		return dao.find(id);
	}

	public List<BankAccount> findAll() {
		return dao.findAll();
    }

	public void save(BankAccount person) {
		dao.save(person);
	}

	public void remove(BankAccount person) {
		dao.remove(person);
	}
	
	public boolean exists(BankAccount person) {
		return dao.exists(person);
	}
}
