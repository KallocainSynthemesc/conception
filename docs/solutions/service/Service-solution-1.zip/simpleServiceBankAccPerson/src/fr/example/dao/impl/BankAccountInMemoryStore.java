package fr.example.dao.impl;

import java.util.ArrayList;
import java.util.List;

import fr.example.dao.interfaces.BankAccountDAO;
import fr.example.model.BankAccount;
import fr.example.model.Person;

public class BankAccountInMemoryStore implements BankAccountDAO{
	
	private final List<BankAccount> store = new ArrayList<BankAccount>();
	
	@Override
	public BankAccount find(String id) {
		BankAccount bankAcc = store.stream()
                .filter(acc -> id.equals(acc.getAccountIdentifier()))
                .findAny()
                .orElse(null);
        return bankAcc;
	}

	@Override
	public List<BankAccount> findAll() {
		return store;
    }

	@Override
	public void save(BankAccount bankAccount) {
		if(!exists(bankAccount)) {
			store.add(bankAccount);
		}
	}

	@Override
	public void remove(BankAccount bankAccount) {
		store.remove(bankAccount);
	}
	
	@Override
	public boolean exists(BankAccount bankAccount) {
		return store.contains(bankAccount);
	}

	@Override
	public BankAccount findByAccountOwner(Person owner) {
		BankAccount bankAcc = store.stream()
                .filter(acc -> owner.equals(acc.getAccountOwner()))
                .findAny()
                .orElse(null);
        return bankAcc;
	}

	@Override
	public BankAccount findByConsultant(Person owner) {
		BankAccount bankAcc = store.stream()
                .filter(acc -> owner.equals(acc.getBankConsultant()))
                .findAny()
                .orElse(null);
        return bankAcc;
	}
}
