package fr.example.main;

import java.util.List;

import fr.example.dao.impl.BankAccountInMemoryStore;
import fr.example.dao.impl.PersonInMemoryStore;
import fr.example.model.BankAccount;
import fr.example.model.Person;
import fr.example.services.BankAccountService;
import fr.example.services.PersonService;	

public class Main {
    
	public static void main(String[] args) {
		Person person1 = new Person(1L, "Kilian", "Schropp");
		Person person2 = new Person(2L, "Holz", "Michel");
		Person person3 = new Person(3L, "Peter", "M�ller");
		
		BankAccount account = new BankAccount("abz", person1, person2, "BGE-bank");
		BankAccount account2 = new BankAccount("yz-hez", person2, person3, "big-K-bank");
		
		PersonInMemoryStore personDao = new PersonInMemoryStore();
		BankAccountInMemoryStore bankaccountDao = new BankAccountInMemoryStore();
		
		PersonService personService = new PersonService(personDao, bankaccountDao);
		personService.save(person1);
		personService.save(person2);
		personService.save(person3);
		
		BankAccountService bankaccountService = new BankAccountService(bankaccountDao);
		bankaccountService.save(account);
		bankaccountService.save(account2);
		
		List<Person> persons = personService.findAll();
		printPersons(persons);
		
		List<BankAccount> accounts = bankaccountService.findAll();
		printBankAccount(accounts);
		
		System.out.println("#### avant de supprimer ####");
		personService.remove(person2);
		
		persons = personService.findAll();
		accounts = bankaccountService.findAll();
		printPersons(persons);
		printBankAccount(accounts);
    }
	
	private static void printPersons(List<Person> persons) {
		for(Person person : persons) {
			System.out.println("Person: " + person);
		}
	}
	
	private static void printBankAccount(List<BankAccount> bankAccount) {
		for(BankAccount account : bankAccount) {
			System.out.println("BankAccount: "+ account);
		}
	}
}
