package fr.example.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Person {

	private long personNum;
    private String firstName;
    private String lastName;

    private List<String> phoneNumbers = new ArrayList<String>();

    public Person() {}
    
    public Person(long personNum, String firstName, String lastName) {
        this.personNum = personNum;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public long getPersonNum() {
        return personNum;
    }

    public void setPersonNum(long personNum) {
        this.personNum = personNum;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public List<String> getPhoneNumbers() {
        return phoneNumbers;
    }

    public void setPhoneNumbers(List<String> phoneNumbers) {
        this.phoneNumbers = phoneNumbers;
    }
    
    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof Person)) {
            return false;
        }
        Person otherPerson = (Person) o;
        return personNum == otherPerson.personNum
                && Objects.equals(firstName, otherPerson.firstName)
                && Objects.equals(lastName, otherPerson.lastName)
                && Objects.equals(phoneNumbers, otherPerson.phoneNumbers);
    }
    
    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + (int) (personNum ^ (personNum >>> 32));
		result = prime * result + ((phoneNumbers == null) ? 0 : phoneNumbers.hashCode());
		return result;
	}
    
    @Override
    public String toString() {
    	return "Person [personNum=" + personNum + ", firstName=" + firstName + ", lastName=" + lastName
    			+ ", phoneNumbers=" + phoneNumbers + "]";
    }

}