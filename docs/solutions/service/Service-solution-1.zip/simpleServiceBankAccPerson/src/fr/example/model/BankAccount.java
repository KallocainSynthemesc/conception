package fr.example.model;

public class BankAccount {

    private String accountIdentifier;
	private Person accountOwner;
    private Person bankConsultant;
    private String bankName;
    
    public BankAccount() {}

	public BankAccount(String accountIdentifier, Person accountOwner, Person bankConsultant, String bankName) {
    	this.accountOwner = accountOwner;
    	this.accountIdentifier = accountIdentifier;
    	this.bankConsultant = bankConsultant;
    	this.bankName = bankName;
    }
    
    public String getAccountIdentifier() {
    	return accountIdentifier;
    }
    
    public void setAccountIdentifier(String accountIdentifier) {
    	this.accountIdentifier = accountIdentifier;
    }
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public Person getBankConsultant() {
		return bankConsultant;
	}
	public void setBankConsultant(Person bankConsultant) {
		this.bankConsultant = bankConsultant;
	}
	public Person getAccountOwner() {
		return accountOwner;
	}
	public void setAccountOwner(Person accountOwner) {
		this.accountOwner = accountOwner;
	}
	
    @Override
	public String toString() {
		return "BankAccount [accountIdentifier=" + accountIdentifier + ", accountOwner=" + accountOwner
				+ ", bankConsultant=" + bankConsultant + ", bankName=" + bankName + "]";
	}
}
