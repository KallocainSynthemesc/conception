package fr.example.services;

import java.util.List;
import java.util.Optional;

import fr.example.dao.interfaces.BankAccountDAO;
import fr.example.dao.interfaces.PersonDAO;
import fr.example.model.Person;

public class PersonService{
	
	final PersonDAO dao;
	final BankAccountDAO bankAccDao;
	
	public PersonService(PersonDAO dao, BankAccountDAO bankAccDao) {
		this.dao = dao;
		this.bankAccDao = bankAccDao;
	}
	
	public Person find(String id) {
		return dao.find(id);
	}

	public List<Person> findAll() {
		return dao.findAll();
    }

	public void save(Person person) {
		dao.save(person);
	}

	public void remove(Person person) {
		bankAccDao.remove(bankAccDao.findByAccountOwner(person));
		Optional.ofNullable(bankAccDao.findByConsultant(person))
        	.ifPresent(obj -> obj.setBankConsultant(null));
		dao.remove(person);
	}
	
	public boolean exists(Person person) {
		return dao.exists(person);
	}
}
