import java.lang.Math;

public class Window extends Rectangle{
  public Window(final int width, final int height){
    super(width, height);
  }
  public void draw(){
      printHorizontal('#');
      for(int j=0;j<this.height-2;j++) {
        if(j == (Math.floor(this.height/2) -1)){
          printHorizontal('#');
        }
        else{
          printVertical('#');
        }
      }
      printHorizontal('#');
  }

  private void printVertical(char marker) {
      System.out.print(marker);
      for (int j = 0; j < this.width-2; j++) {
          if(j == (Math.floor(this.width/2) -1)){
            System.out.print('#');
          }
          else{
            System.out.print(' ');
          }
      }
      System.out.println(marker);
  }

  private void printHorizontal(char marker) {
      for (int j = 0; j < this.width-1; j++) {
          System.out.print(marker);
      }
      System.out.println(marker);
  }
}