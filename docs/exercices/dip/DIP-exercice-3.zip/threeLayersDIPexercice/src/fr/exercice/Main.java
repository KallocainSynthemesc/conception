package fr.exercice;

import fr.exercice.controller.InventoryController;
import fr.exercice.dao.ProductDAO;
import fr.exercice.model.Product;
import fr.exercice.service.InventoryService;
import fr.exercice.service.InventoryServiceImpl;
import fr.exercice.view.ConsoleInterface;

class Main {
    public static void main(String... args) throws Exception {
        final ConsoleInterface ui = new ConsoleInterface();
        final ProductDAO productDAO = new ProductDAO();
        final InventoryService<Product> productInventoryService = new InventoryServiceImpl<Product>(productDAO);
        
        final InventoryController inventoryController = new InventoryController(ui, productInventoryService);
      
        inventoryController.startup();
      
        while (true) {
            inventoryController.showChoices();
            inventoryController.getChoice();
            inventoryController.choiceAction();
        }
    }
}