package fr.exercice.controller;

import java.util.List;

import fr.exercice.model.Product;
import fr.exercice.service.InventoryService;
import fr.exercice.view.UserInterface;

//Presentation Layer / Controller du MVC
//Pour certains, il s'agit du application layer / domain layer
public class InventoryController {

	final UserInterface<String> ui;
	final InventoryService<Product> productService;
	String choice;

	public InventoryController(final UserInterface<String> ui, final InventoryService<Product> service) {
		this.ui = ui;
		this.productService = service;
	}

	public void startup() {
		ui.displayMessage("Bienvenue dans le syst�me de gestion des stocks !");
	}

	public void showChoices() {
		ui.displayMessage("Veuillez choisir une action :");
		ui.displayMessage("1. Ajouter un produit");
		ui.displayMessage("2. Voir tous les produits");
		ui.displayMessage("3. Quitter");
	}

	public void getChoice() {
		this.choice = ui.getUserInput();
	}

	public void choiceAction() {
		switch (this.choice) {
		case "1":
			ui.displayMessage("Veuillez saisir le nom du produit :");
			String name = ui.getUserInput();
			ui.displayMessage("Veuillez saisir le prix du produit :");
			double price = Double.parseDouble(ui.getUserInput());
			Product product = new Product(name, price);
			this.productService.addToInventory(product);
			ui.displayMessage("Produit ajout�!");
			break;

		case "2":
			List<Product> items = this.productService.listInventory();
			ui.displayMessage("Tous les produits :");
			for (Product item : items) {
				ui.displayMessage(item.getName() + " - $" + item.getPrice());
			}
			break;

		case "3":
			ui.displayMessage("Au revoir !");
			System.exit(0);

		default:
			ui.displayMessage("Choix non valide, veuillez r�essayer.");
			break;
		}
	}
}
