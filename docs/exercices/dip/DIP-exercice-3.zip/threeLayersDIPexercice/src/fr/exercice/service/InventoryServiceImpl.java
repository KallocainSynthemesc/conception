package fr.exercice.service;

import java.util.List;

import fr.exercice.dao.DAOable;

/*Domain Layer / Business logic*/
public class InventoryServiceImpl<T> implements InventoryService<T>{
    private DAOable<T> inventoryDAO;
    
    public InventoryServiceImpl(DAOable<T> inventoryDAO) {
        this.inventoryDAO = inventoryDAO;
    }
    
    public void addToInventory(T t) {
    	inventoryDAO.add(t);
    }
    
    public List<T> listInventory() {
        return inventoryDAO.list();
    }
}
