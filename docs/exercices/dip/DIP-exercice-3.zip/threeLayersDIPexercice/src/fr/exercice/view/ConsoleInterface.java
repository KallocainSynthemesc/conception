package fr.exercice.view;

import java.util.Scanner;

//Presentation Layer / View du MVC
public class ConsoleInterface implements UserInterface<String>{
  private Scanner scanner;
  
  public ConsoleInterface() {
      this.scanner = new Scanner(System.in);
  }
  
  public void displayMessage(String message) {
      System.out.println(message);
  }
  
  public String getUserInput() {
      return scanner.nextLine();
  }
}
