package fr.exercice.model;

//Model / Model du MVC
public final class Product {
	final String name;
	final double price;

	public Product(final String name, final double price) {
		this.name = name;
		this.price = price;
	}

	public String getName() {
		return this.name;
	}

	public double getPrice() {
		return this.price;
	}

}